export default function Search() {
  return (
    <>
      <input type='text' />
    </>
  )
}
